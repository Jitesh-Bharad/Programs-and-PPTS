export class Config{
    static signupURL="https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=AIzaSyCVzj9sS_LKaT7Vg8AFMJE9zyjp_ZxxlcY";

    static loginURL="https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=AIzaSyCVzj9sS_LKaT7Vg8AFMJE9zyjp_ZxxlcY";    
}
