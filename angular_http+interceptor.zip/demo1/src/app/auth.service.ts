import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {Config} from './config';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http:HttpClient) { }

  signUp(body:any)
  {
    let payLoad={...body,returnSecureToken:true}    
    return this.http.post(Config.signupURL,payLoad);
  }

  login(body:any)
  {
    let payLoad={...body,returnSecureToken:true}    
    return this.http.post(Config.loginURL,payLoad);
  }

  saveToken(token:string)
  {
    localStorage.setItem('id-token',token)
  }
  
  getToken()
  {
   let token=localStorage.getItem('id-token')
   return token;
  }
  
  deleteToken()
  {
    localStorage.clear();
  }
}
