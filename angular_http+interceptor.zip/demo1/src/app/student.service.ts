import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor(private http:HttpClient) { }

  add(student:any)
  {
    let url="https://testapis-c90ab-default-rtdb.firebaseio.com/students.json";
    return this.http.post(url,student);
  }
}
