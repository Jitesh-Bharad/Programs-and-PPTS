import { sum,multiply } from "./math.js";

console.log();
console.log();
