let m=require('./math.js');

console.log('hello world');
console.log(m.sum(10,2));
console.log(m.multiply(10,2));
console.log(m.divide(10,2));
console.log('good evening');