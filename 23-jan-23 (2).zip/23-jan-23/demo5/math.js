module.exports.sum=function s(a,b)
{
    return a+b;
}

module.exports.multiply=function m(a,b)
{
    return a*b
}

module.exports.divide=function d(a,b)
{
    return a/b;
}