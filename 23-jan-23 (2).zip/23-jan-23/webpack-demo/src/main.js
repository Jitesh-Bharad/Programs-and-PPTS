let dom=require('./load-dom.js');
let isVisible=true;
dom.paraElement.style.background='red';
dom.buttonElement.style.background='black';
dom.buttonElement.style.color='white';

// function toggle()
// {
//     if(isVisible)
//     {
//         isVisible=false;
//         paraElement.style.display='none';
//         buttonElement.innerHTML='Hide'
//     }else{
//         isVisible=true;
//         paraElement.style.display='block';
//         buttonElement.innerHTML='Show';
//     }
// }