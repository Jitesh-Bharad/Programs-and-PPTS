module.exports.paraElement=document.getElementById('p1');
module.exports.buttonElement=document.getElementById('b1');