import {sum,multiply,divide} from './math.js';

console.log('hello world');
console.log(sum(10,2));
console.log(multiply(10,2));
console.log(divide(10,2));
console.log('good evening');