Regular Expression  : Generic expressions which are 
                     used to test for string patterns.


eg : matching email , passwords etc. 


[abc] : strings composed of either of a , b or c 
[a-z] : string composed of any letter from a to z
[A-Z] : string composed of any letter from A to Z
[a-zA-Z] : strings composed of a-z or A-Z
[a-zA-Z0-9] : digits and capital and small alphabats



[]? : 0 or 1 character

eg : [a-z]? : means strings of length either 0 or 1, but containing
              only any char from a to z

              a : yes
                : yes             
              ac : no
              c  : yes
              A : no

[]+ : 1 or more 

eg : [a-z]+
    a : yes , ab : yes ,  : no , abc : yes 

[]* : zero or more characters

eg : [0-9]*   12: yes ,  : yes , 12a : no  


[]{n} : where n is an integer number, exactly n size string

eg : [a-z]{3} : abc : valid , a : invalid, abcd : invalid

[]{n,} : strings with size n or more.

eg : [a-z]{2,} : 34 : invalid , ab : valid , abc : valid
                  a : invalid

[]{n, m} : strings of length ranging from n to m

eg : [a-z]{2,6} : a : invalid , ab : valid , 

               abcde : valid , azxyk : valid , abcdefzkle: invalid




eg : [0-9]{6} : postal code in india

eg : [a-zA-Z0-9]+@[a-zA-Z]+.[a-zA-Z]{2,3}


eg : [] : username should start with capital letter, 
           can be composed of small and capital letters only
           and maximum length be 10 , minimum length 1
[A-Z]{1}[a-zA-Z]{0,9}


eg : password must contain atleast a character, a digit
     and a special character. total length should be 
    less than or equal to 10 and more than or equal to 5. 



eg : mobile number 











