require('dotenv').config(); 

console.log(process.env.U_NAME);
console.log(process.env.EMAIL);
