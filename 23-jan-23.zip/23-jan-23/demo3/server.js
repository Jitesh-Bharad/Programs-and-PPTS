const { copyFileSync } = require('fs');
let http=require('http');
let fs=require('fs');

let server=http.createServer((req,resp)=>{
    console.log(req.url);
    switch(req.url)
    {
        case '/home':
            {
                fs.readFile('index.html','utf-8',(err,data)=>{
                    if(err)
                    {
                        console.log(err)
                    }else{
                        resp.end(data);
                    }
                })
            }
            break;
            case '/':
                {
                    fs.readFile('index.html','utf-8',(err,data)=>{
                        if(err)
                        {
                            console.log(err)
                        }else{
                            resp.end(data);
                        }
                    })
                }
                break;
    
        case '/about':
            {
                fs.readFile('about.html','utf-8',(err,data)=>{
                    if(err)
                    {
                        console.log(err)
                    }else{
                        resp.end(data);
                    }
                })
            }
            break;
        case '/contact':
            {
                fs.readFile('contact.html','utf-8',(err,data)=>{
                    if(err)
                    {
                        console.log(err)
                    }else{
                        resp.end(data);
                    }
                })
            }
        break;
    }
});

server.listen(80,()=>{
    console.log('listening....');
})