const m=require('./greet.js');
require('../styles/theme.sass');

function test()
{
    console.log('test1');
    console.log(m.greet());
    console.log('test2');
}

test();