
module.exports.greet=function()
{
    return "hello world good morning";
}