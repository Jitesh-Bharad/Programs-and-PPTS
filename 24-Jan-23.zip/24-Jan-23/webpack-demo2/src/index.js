const m=require('./greet.js');
function test()
{
    console.log('test1');
    console.log(m.greet());
    console.log('test2');
}

test();