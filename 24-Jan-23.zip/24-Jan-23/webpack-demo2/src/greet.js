
module.exports.greet=function greet()
{
    return "hello world good morning";
}