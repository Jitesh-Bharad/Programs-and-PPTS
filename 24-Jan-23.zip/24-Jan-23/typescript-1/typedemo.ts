type Student={name:string,rollno:number};

let obj:{ename:string,empid:number,salary:number};
let obj1:{ename:string,empid:number,salary:number};

let std1:Student;
let std2:Student;




