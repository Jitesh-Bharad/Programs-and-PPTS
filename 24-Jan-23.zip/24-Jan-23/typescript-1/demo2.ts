let marks:number[]=[12,100];
// let marks:readonly number[]=[12,100];
marks.push(12);
marks.push(90);
marks.push(89);
console.log(marks);
marks.pop();
marks.pop();
console.log(marks);
