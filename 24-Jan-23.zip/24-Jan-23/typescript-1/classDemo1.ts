class Emp{
    public fname:string;
    public lname:string;
    private salary:number;
    protected xyz:number=9;

    constructor(f:string,l:string,s:number){
        this.fname=f;
        this.lname=l;
        this.salary=s;
    }
    show():void
    {
        console.log(this.fname);
        console.log(this.lname);
        console.log(this.salary);
    }
}

let e11=new Emp("sakshi","rana",1040000);
let e12=new Emp("vanshika",".",1040000);
let e13=new Emp("muskan","dhapa",1040000);

e11.show();
e12.show();
e13.show();

e11.fname='def';
// e11.xyz=90;//error from ts