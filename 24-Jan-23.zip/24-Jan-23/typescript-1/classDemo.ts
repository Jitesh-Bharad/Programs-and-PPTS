// class Emp{
//     fname:string;
//     lname:string;
//     salary:number;
//     constructor(f:string,l:string,s:number){
//         this.fname=f;
//         this.lname=l;
//         this.salary=s;
//     }
//     show():void
//     {
//         console.log(this.fname);
//         console.log(this.lname);
//         console.log(this.salary);
//     }
// }

// let e11=new Emp("sakshi","rana",1040000);
// let e12=new Emp("vanshika",".",1040000);
// let e13=new Emp("muskan","dhapa",1040000);

// e11.show();
// e12.show();
// e13.show();

