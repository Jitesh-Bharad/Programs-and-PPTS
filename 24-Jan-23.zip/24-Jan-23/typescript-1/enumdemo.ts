enum weekdays{Monday=10,Tuesday,Wednesday=20};

console.log(weekdays.Monday);
console.log(weekdays.Tuesday);
console.log(weekdays.Wednesday);


