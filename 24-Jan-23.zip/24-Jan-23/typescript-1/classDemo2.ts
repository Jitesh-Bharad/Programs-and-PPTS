class A{
    public x:string='hello';
    private a:number=1;
    protected b:number=2;
}

class B extends A{

    show()
    {
 //       console.log(this.a);//error
        console.log(this.b);
        console.log(this.x);
    }
}








