// let var1 : string;
// let var2:number;
// let var3:number | string;
// var3 = 12;
// console.log(typeof var3);
// var3='hello';
// console.log(typeof var3);

function printStatusCode(code: string | number) 
{
    console.log(`My status code is ${code}.`)
}
printStatusCode(404);
printStatusCode('404');
