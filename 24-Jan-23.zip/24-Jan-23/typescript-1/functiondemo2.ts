type Employee={fname:string,empid:number,salary:number};

function findMaxEmp(emp1:Employee,emp2:Employee):Employee{

    if(emp1.salary>emp2.salary)
    {
        return emp1;
    }
    return emp2;
}
let e1:Employee={fname:"john",empid:1,salary:9000000};
let e2:Employee={fname:"paul",empid:2,salary:19000000};
console.log(findMaxEmp(e1,e2));
