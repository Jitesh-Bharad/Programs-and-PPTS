// let x:string;
// x='ramesh';
// console.log(x);
let b:number=9;
let a:unknown;
if(b>=10)
{
    a=5;
}
else{
    a='hello';
}
console.log(b);
console.log(a);
