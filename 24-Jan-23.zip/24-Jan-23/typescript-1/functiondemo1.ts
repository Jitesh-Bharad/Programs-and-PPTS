
function greet():void
{
    console.log('hello world good noon');
}

function sum(a:number,b:number):number{
    return a+b;
}