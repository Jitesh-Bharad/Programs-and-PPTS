
let x:[string,number,boolean];

x=['hello',23,false];//valid

// x=[1,2,4];//invalid

console.log(x);