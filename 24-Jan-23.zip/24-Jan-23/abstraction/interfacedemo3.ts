interface A{
    a():void;
}

interface B{
    b():void;
}

class Test implements A,B{

    b(): void {
        console.log('b');
    }
    a(): void {
        console.log('a')
    }
}

let obj:Test=new Test();
obj.b();//b
obj.a();//a

// let obj1:A=new Test();
// obj.b();//error
// obj.a();//a

// let obj1:B=new Test();
// obj.b();//b
// obj.a();//error
