interface Runnable{
    run():void
}
interface Playable extends Runnable{
    play():void
}
class Cricketer implements Playable{
 
    play(): void {
        console.log('playing cricket');
    }
    run(): void {
        console.log('running for practice');
    }    
}
let p : Playable;
p=new Cricketer();
p.play();
p.run();
