abstract class Fruit{
    public abstract getPrice():number;
    public grow()
    {
        console.log('growing...');
    }
}
class Mango extends Fruit{
 public getPrice() :number{
     return 100;
 }
}
class Apple extends Fruit{
    public getPrice():number {
        return 150;
    }
}
class Orange extends Fruit{
    public getPrice():number {
        return 80;
    }
}
let input:string='orange';
let f:Fruit=new Mango();
if(input=='apple')
{
    f=new Apple();
}
else if(input=='orange'){
    f=new Orange();
}
console.log(f.getPrice());


