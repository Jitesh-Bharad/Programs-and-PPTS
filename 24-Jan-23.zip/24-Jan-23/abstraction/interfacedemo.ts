// interface Playable{
//      play():void;
// }
// class Musician implements Playable{    
//     public play(): void {
//         console.log('Playing Guitar');
//     }
// }
// class Cricketer implements Playable{
//     play(): void {
//         console.log('Playing cricket');
//     }
// }

// let p:Playable;
// let inp:string='music';

// if(inp=='music'){
//     p=new Musician();
// }else{
//     p=new Cricketer();
// }
// p.play();