import { AbsoluteSourceSpan } from '@angular/compiler';
import { Component, ɵgetInjectableDef } from '@angular/core';
import {FormGroup ,FormBuilder,FormControl,Validators} from '@angular/forms';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo1';
  constructor(private fb:FormBuilder){

  }  
  profile= this.fb.group({
    name:['',[Validators.required,Validators.minLength(3),Validators.maxLength(10)]],
    password:this.fb.control(''),//equivalent to password:[''],
    email:[''],
    address:this.fb.group({
      hno:[],
      city:[''],
      state:[''],
      pincode:[]      
    })
  })
  // profile=new FormGroup({
  //   name:new FormControl('',[Validators.required,
  //                           Validators.minLength(3),
  //                           Validators.maxLength(10)]),
  //   password:new FormControl(''),
  //   email:new FormControl(''),   
  //   address: new FormGroup({
  //     hno:new FormControl(),
  //     city:new FormControl(''),
  //     state:new FormControl(''),
  //     pincode:new FormControl()
  //   })
  // });

  submit()
  {
   console.log(this.profile.value); 
  }
}











// * Wherever the service is injected  , that component/service will
// get the reference of the injected Service automatically.

// * A service can be injected in another service or 
// a component also.









