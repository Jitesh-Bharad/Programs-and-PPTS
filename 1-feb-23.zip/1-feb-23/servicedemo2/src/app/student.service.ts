import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import {Student} from './types/Student';
@Injectable({
  providedIn: 'root'
})
export class StudentService {

  students:Student[]=[
    {name:'jishnu',rollno:1,marks:100},
    {name:'paul',rollno:2,marks:90},
    {name:'muskan',rollno:3,marks:100},
    {name:'sakshi',rollno:4,marks:100},
    {name:'vanshika',rollno:5,marks:100},
    {name:'surbhi',rollno:6,marks:100},
    {name:'natarajan',rollno:7,marks:100},
    {name:'piyali',rollno:8,marks:100}, 
    {name:'nisha',rollno:9,marks:100},
    {name:'senta',rollno:10,marks:100},        
    {name:'amrita',rollno:11,marks:100},
    {name:'sachpreet',rollno:12,marks:100},        
  ]
  constructor() { }

 async getAll():Promise<Student[]>
  {
    let p:Promise<Student[]>=new Promise((resolve,reject)=>{
      resolve(this.students);      
    });
    return p;
  }

  getAllObs():Observable<Student>
  {
    const observable:Observable<Student> = new Observable((subscriber) => {
      for(let student of this.students){
        subscriber.next(student)      
      }
    })
   let newObs= observable.pipe(map((std)=>{std.clg='msi';return std}))
   return newObs;
  }

}

