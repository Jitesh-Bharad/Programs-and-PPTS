export type Student={
    name:string,
    rollno:number,
    marks:number,
    clg?:string
}