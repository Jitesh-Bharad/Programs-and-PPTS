import { Component, OnInit } from '@angular/core';
import { StudentService } from './student.service';
import { Student } from './types/Student';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'servicedemo2';
  students:Student[]=[];
  constructor(private studentServ:StudentService){

  }
  
  ngOnInit() {
//   this.students=await this.studentServ.getAll();  

    this.studentServ.getAllObs().subscribe((data)=>{
      console.log(data);
//      this.students.push(data);
    })
  }
}











