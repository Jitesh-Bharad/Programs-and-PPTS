import { Component, DoCheck } from '@angular/core';
import { timeInterval } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements DoCheck {
  ngDoCheck(): void {

  }

  title = 'servicedemo1';
}















// Promise can not send stream of data over time  . 
// Once the promise is resolved , then no more data can
// be sent over .

// whereas, observables can be used at places where 
// a stream of data has to be sent over time. 





