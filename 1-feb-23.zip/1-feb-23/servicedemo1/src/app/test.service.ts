import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'//This means that the service is
                    //registered at application level
})

export class TestService {
  value:string='';
  setValue(value:string)
  {
    this.value=value;
  }
  getValue(){
    return this.value;
  }
  constructor() { }

  }











  The service can respond with data using either of 2 : 


  a. Promise
  b. Observables












Producer : Service



Consumer : Component







