import { Component, DoCheck } from '@angular/core';
import { TestService } from '../test.service';

@Component({
  selector: 'app-a',
  templateUrl: './a.component.html',
  styleUrls: ['./a.component.css'],
  providers:[TestService]
})
export class AComponent implements DoCheck {   
  constructor(private serv:TestService) { }
  val:string='';
  val2:string='';
  ngDoCheck(): void {
   this.val2=this.serv.getValue();
  }
  set()
  {
    this.serv.setValue(this.val);
  }
}
