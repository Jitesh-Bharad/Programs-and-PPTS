import { Component, OnInit } from '@angular/core';
import { TestService } from '../test.service';
@Component({
  selector: 'app-b',
  templateUrl: './b.component.html',
  styleUrls: ['./b.component.css'],
  providers:[TestService]
})
export class BComponent implements OnInit {
  constructor(private serv:TestService) { }
  ngOnInit(): void {
  }
  val:string='';
  val2:string='';
  ngDoCheck(): void {
   this.val2=this.serv.getValue();
  }
  set()
  {
    this.serv.setValue(this.val);
  }
}
