import { CHANGE_NAME_ACTION, DECREMENT_COUNTER_ACTION, INCREMENT_COUNTER_ACTION, RESET_COUNTER_ACTION } from "../ActionConstants";

const initialState={name:'',score:0};

export const ScoreReducer=(prevState=initialState,action)=>{

    switch(action.type)
    {
        case INCREMENT_COUNTER_ACTION:{const newState={...prevState,score:prevState.score+1};return newState};
        case DECREMENT_COUNTER_ACTION:{const newState= {...prevState,score:prevState.score-1};return newState};
        case RESET_COUNTER_ACTION:{const newState={...prevState,score:action.payload};return newState};
        case CHANGE_NAME_ACTION:{const newState={...prevState,name:action.payload};return newState; };
        default:return prevState;
    }
}