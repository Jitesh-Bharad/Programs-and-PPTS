import { combineReducers } from "redux";
import { ScoreReducer } from "./ScoreReducer";

export const rootReducer=combineReducers({ScoreReducer});