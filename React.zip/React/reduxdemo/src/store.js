import { configureStore } from "@reduxjs/toolkit";
import { rootReducer } from "./reducers/RootReducer";

export const store=configureStore({reducer:rootReducer})











//Step 1 : 
// Create the Actions 
//Step 2  
//Create reducers
//Step 3 :
//Create rootReducer by combining all reducers(make use of combineReducers method)
//Step4 : Create store object by calling configureStore method of reduxjs/toolkit
//Step 5 : Bind the react app with the redux store with Provider component
