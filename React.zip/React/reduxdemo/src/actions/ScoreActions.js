import { CHANGE_NAME_ACTION, DECREMENT_COUNTER_ACTION, INCREMENT_COUNTER_ACTION, RESET_COUNTER_ACTION, RESET_COUNTER_VALUE } from "../ActionConstants";

export function getIncrementAction(){
    return {type:INCREMENT_COUNTER_ACTION}
}

export function getDecrementAction(){
    return {type:DECREMENT_COUNTER_ACTION}
}

export function getResetAction(value){
    return {type:RESET_COUNTER_ACTION,payload:value}
}

export function getUpdateNameAction(value){
    return {type:CHANGE_NAME_ACTION,payload:value}
}