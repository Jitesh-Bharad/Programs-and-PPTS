import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getDecrementAction, getIncrementAction, getResetAction, getUpdateNameAction } from "../actions/ScoreActions";

export function Scoreboard()
{
     const globalObj=useSelector((state)=>{console.log(state);return state.ScoreReducer});
     const [name,setName]=useState('');
     const dispatch=useDispatch()

    function handleIncrement()
    {
        dispatch(getIncrementAction());
    }

    function handleDecrement()
    {
        dispatch(getDecrementAction());
    }

    function handleReset()
    {
        dispatch(getResetAction(0));
    }

    function handleUpdateName()
    {
        dispatch(getUpdateNameAction(name));
    }

    return(
        <React.Fragment>            
            <input type='text' onChange={(e)=>{setName(e.target.value)}} placeholder="Enter name"/>
            <button onClick={handleUpdateName}>Update Name</button>            
            <p>Score : {globalObj.score}</p>
            <p>NAME : {globalObj.name}</p>
            <button onClick={handleIncrement}>+</button>
            <button onClick={handleDecrement}>-</button>
            <button onClick={handleReset}>Reset</button>
        </React.Fragment>
    )
}