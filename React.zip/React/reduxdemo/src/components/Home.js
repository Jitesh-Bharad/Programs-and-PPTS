import { useSelector } from "react-redux"

export function Home()
{
   const globalObj=useSelector((state)=>{return state.ScoreReducer} )
    return(
        <p>Welcome {globalObj.name}, your score is {globalObj.score} </p>
    )
}