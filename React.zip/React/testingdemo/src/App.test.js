import { render, screen } from '@testing-library/react';
import App from './App';

test('renders learn react link', () => {//belongs to jest
  render(<App />);//Done by RTL
  const linkElement = screen.getByText(/learn react/i);//Done by RTL
  expect(linkElement).toBeInTheDocument();//jest assertion
});

test('first test case',()=>
{
  render(<App />);//Done by RTL
  const linkElement = screen.getByText("Hello World");//Done by RTL
  expect(linkElement).toBeInTheDocument();//jest assertion
});


