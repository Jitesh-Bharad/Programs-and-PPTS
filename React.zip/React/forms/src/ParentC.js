import React, { useState } from "react";
import { ChildC } from "./ChildC";

export function ParentC(){

   const [marks,setMarks]=useState();

   function handleChangeMarks(e)
   {
    setMarks(e.target.value);
   }

   return(
    <React.Fragment>
    <input type='number' onChange={handleChangeMarks} placeholder="Enter marks"/>
    <ChildC marks={marks}></ChildC>
    </React.Fragment>
   )
}