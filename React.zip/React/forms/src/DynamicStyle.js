export function DynamicStyle(props)
{
    let styleInfo={fontSize:'30px',width:'300px',height:'300px'}
    styleInfo['background']=props.bg;

    return (
        <div style={styleInfo}>
        </div>
    )
}