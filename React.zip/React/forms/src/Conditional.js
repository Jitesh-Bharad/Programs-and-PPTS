export function Conditional(props)
{
    // if(props.age>=18)
    // {
    //     return(
    //         <p>You can Vote</p>
    //     )
    // }    
    // return(
    //     <p>You can not Vote</p>
    // )
    return (
        props.age>=18?(<p>You can vote</p>):(<p>You can not vote</p>)
    )
}