import './DynamicClass.css';

export function DynamicClass(props)
{
    let allClasses="c1";
    if(props.shadow){
        allClasses=allClasses+" c3";
    }
    return (
        //Adding single class statically
        // <div className="c1">
        //     <p>Testing Classes Dynamically</p>
        // </div>

        //     //Adding multiple classes statically
        // <div className="c1 c3">
        //     <p>Testing Classes Dynamically</p>
        // </div>

        <div className={allClasses}>
            <p>Testing Classes Dynamically</p>
        </div>


    )
}