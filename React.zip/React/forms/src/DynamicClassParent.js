import React from "react";
import { DynamicClass } from "./DynamicClass";

export function DynamicClassParent(){

    return (
        <React.Fragment>
        <DynamicClass></DynamicClass>
        <DynamicClass shadow></DynamicClass>
        </React.Fragment>
    )
}