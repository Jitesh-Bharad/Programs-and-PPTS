import { useState } from "react"
import { DynamicStyle } from "./DynamicStyle";

export function DynamicStyleParent()
{
   const [color,setColor]=useState('black');

    function handleColorChange(e)
    {
        setColor(e.target.value);
    }

    return(
        <form>
            <input onChange={handleColorChange} type='text' placeholder="Enter color"/>
            <DynamicStyle bg={color}></DynamicStyle>
        </form>
    )
}