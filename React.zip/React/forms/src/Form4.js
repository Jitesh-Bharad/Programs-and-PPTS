export function Form4(){

    let username='';
    let password='';
    let email='';

    function handleSubmit(e)
    {
        e.preventDefault();//it will prevent the default behaviour of form submission 
                           //ie. it will prevent re-loading of the page
        console.log(username.value);//username will contain the reference
                            //of input field username and using value attribute
                            //we are reading the value of that control.
        console.log(password.value);
        console.log(email.value);        
    }

    return(
        <form onSubmit={handleSubmit}>
            <input type='text' ref={(uname)=>{username=uname}} placeholder="Enter username"/>
            <input type='password' ref={(pass)=>{password=pass}} placeholder="Enter password"/>
            <input type='email' ref={(em)=>{email=em}} placeholder="Enter email"/>
            <input type='submit' value='Submit'/>            
        </form>
    )
}