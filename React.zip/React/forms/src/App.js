import logo from './logo.svg';
import './App.css';
import { Form1 } from './Form1';
import { Form2 } from './Form2';
import { Form3 } from './Form3';
import { Form4 } from './Form4';
import { Parent } from './Parent';
import { List } from './List';
import { List1 } from './List1';
import { StatefulList } from './StatefulList';
import { Conditional } from './Conditional';
import { ParentC } from './ParentC';
import { DynamicStyle } from './DynamicStyle';
import React from 'react';
import { DynamicStyleParent } from './DynamicStyleParent';
import { DynamicClass } from './DynamicClass';
import { DynamicClassParent } from './DynamicClassParent';

function App() {
  return (
    // <Form1></Form1>
    // <Form2></Form2>
    // <Form3></Form3>
    // <Form4></Form4>
    // <Parent></Parent>
    // <List></List>
    // <List1></List1>
    // <StatefulList></StatefulList>
    // <Conditional age={13}></Conditional>
    // <ParentC></ParentC>
    // <DynamicStyleParent></DynamicStyleParent>
    // <DynamicClass></DynamicClass>
    <DynamicClassParent></DynamicClassParent>
    );
}

export default App;
