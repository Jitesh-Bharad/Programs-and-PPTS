// Lifting the state Up : 
// What ? The state of child is moved up to parent. 
// Why ? If the state of one child is dependent on other child , then 
// moving the states to parent , can do the Task because parent will be the 

import React, { useState } from "react";
import { Child1 } from "./Child1";
import { Child2 } from "./Child2";

// single source of truth 
export function Parent(props)
{
    const[count,setCount] =useState(0);

    function getChildCounter(count)
    {
        setCount(count);
    }

    return(
        <React.Fragment>
        <Child1 count={count} updateCount={getChildCounter} ></Child1>
        <Child2 count={count} updateCount={getChildCounter} ></Child2>
        </React.Fragment>
        )
}