export function Form3(){

    let username='';

    function handleSubmit(e)
    {
        e.preventDefault();//it will prevent the default behaviour of form submission 
                           //ie. it will prevent re-loading of the page
        console.log(username.value);
    }

    return(
        <form onSubmit={handleSubmit}>
            <input type='text' ref={(uname)=>{username=uname;}} placeholder="Enter username"/>
            <input type='submit' value='Submit'/>            
        </form>
    )
}