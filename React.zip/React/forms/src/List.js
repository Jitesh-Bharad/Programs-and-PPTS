export function List(props)
{
    let listItems=['Apple','Banana','Orange','Grapes','Mango'];
    
    // return(
    //     <ul>
    //         {
    //             listItems.map((listItem)=>(<li>{listItem}</li>))
    //         }
    //     </ul>
    // )

    // return(
    //     <table border={1}>
    //         {
    //             listItems.map((listItem)=>(<tr><td>{listItem}</td></tr>))
    //         }
    //     </table>
    // )

    return (
        <select>
            {
                listItems.map((listItem)=>(<option>{listItem}</option>))
            }
        </select>
    )

}