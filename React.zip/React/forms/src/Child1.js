import React, { useState } from "react";
export function Child1(props)
{  
  function increment()
  {
    let current=props.count;
    let next=current+1;
    props.updateCount(next);
  }
  function decrement()
  {
    let current=props.count;
    let next=current-1;
    props.updateCount(next);
  }
  return(
    <React.Fragment>
    <h2>Child I</h2>
    <p>Current Count : {props.count} </p>
    <button onClick={increment}>+</button>    
    <button onClick={decrement}>-</button>    
    </React.Fragment>
  )
}