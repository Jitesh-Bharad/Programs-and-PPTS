import React, { useState } from "react"

export function Form1()
{
    const [name,setName]=useState('Ramesh');

    function handleChangeName(e)
    {
        setName(e.target.value);
    }

    return(
        <React.Fragment>
        <p>Name :  {name}</p>
        <form>
            <input value={name} onChange={handleChangeName} type='text' placeholder="Enter name"/>
        </form>
        </React.Fragment>
    )
}