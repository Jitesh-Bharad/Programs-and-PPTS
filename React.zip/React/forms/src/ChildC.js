export function ChildC(props){

    if(props.marks)
    {
        return (
            // props.marks>=70?<p>Congratulations, You passed</p>:<p>We are Sorry to inform you that you didnt pass</p>
            
            props.marks>=70 && <p>Passed</p>
          );
    }


}