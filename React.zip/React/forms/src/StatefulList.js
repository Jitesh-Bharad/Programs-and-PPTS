import React, { useState } from "react";

export function StatefulList(props)
{
    const [students,setStudents]=useState([]);
    const [currentStudent,setCurrentStudent]=useState({name:'',rollno:0,marks:0});

    function handleChangeName(e)
    {
     setCurrentStudent({...currentStudent,name:e.target.value});
    }
   function handleChangeRollno(e)
    {
        setCurrentStudent({...currentStudent,rollno:e.target.value});

    }
   function handleChangeMarks(e)
    {
        setCurrentStudent({...currentStudent,marks:e.target.value});

    }

    function handleSubmit(e)
    {
        e.preventDefault();
      setStudents([...students,currentStudent]);
    }
    
    return (
        <React.Fragment>
            <form onSubmit={handleSubmit}>
                <input onChange={handleChangeName} type='text' placeholder="Enter username"/>
                <input onChange={handleChangeMarks} type='number' placeholder="Enter marks"/>
                <input onChange={handleChangeRollno} type='number' placeholder="Enter rollno"/>  
                <input type='submit' value='Add'/>              
            </form>
        <table border={1}>
           <thead>
            <tr>
            <th>Name</th>
            <th>Roll No</th>
            <th>Marks</th>            
            </tr>
           </thead>
           <tbody>
           {
                students.map((student,index)=>(
                    <tr key={index}>
                        <td>{student.name}</td>
                        <td>{student.rollno}</td>
                        <td>{student.marks}</td>
                    </tr>
                ))
            }
           </tbody>
        </table>


        </React.Fragment>
    )


}