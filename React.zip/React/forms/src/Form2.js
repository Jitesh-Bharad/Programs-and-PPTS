import { useState } from "react"

export function Form2(){

    const[user,setUser]=useState({username:'',password:'',email:'',course:''});

   function handleChangeUsername(e)
    {
        setUser({...user,username:e.target.value})
    }
   function handleChangePassword(e)
    {
        setUser({...user,password:e.target.value})
    }
   function handleChangeEmail(e)
    {
        setUser({...user,email:e.target.value})
    }

    function handleChangeCourse(e){
        setUser({...user,course:e.target.value});
    }


   function handleSubmit(e)
    {
        e.preventDefault();//it will prevent the default behaviour of form submission 
                           //ie. it will prevent re-loading of the page
        console.log(user);
    }


    return(
        <form onSubmit={handleSubmit}>
            <input onChange={handleChangeUsername} type='text' placeholder="Enter username"/>
            <input onChange={handleChangePassword} type='password' placeholder="Enter password"/>
            <input onChange={handleChangeEmail} type='email' placeholder="Enter email"/>
            <select onChange={handleChangeCourse}>
                <option value='bcom'>BCom</option>
                <option  value='btech'>BTech</option>
                <option value='mba'>MBA</option>
                <option value='mca'>MCA</option>                
            </select>          
            <input type='submit' value='Submit'/>  
        </form>
    )
}














