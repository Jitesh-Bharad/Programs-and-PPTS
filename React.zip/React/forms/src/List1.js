export function List1(props)
{
    let listItems=[
        {name:'ramesh',rollno:1,marks:92},
        {name:'suresh',rollno:2,marks:90},
        {name:'mahesh',rollno:3,marks:81},
        {name:'mukesh',rollno:4,marks:88},
        {name:'ambikesh',rollno:5,marks:99},    
    ]; 

    return (
        <table border={1}>
           <thead>
            <tr>
            <th>Name</th>
            <th>Roll No</th>
            <th>Marks</th>            
            </tr>
           </thead>
           {/* <tbody>
           {
                listItems.map((student,index)=>(
                    <tr key={student.rollno}>
                        <td>{student.name}</td>
                        <td>{student.rollno}</td>
                        <td>{student.marks}</td>
                    </tr>
                ))
            }
           </tbody> */}
           <tbody>
           {
                listItems.map((student,index)=>(
                    <tr key={index}>
                        <td>{student.name}</td>
                        <td>{student.rollno}</td>
                        <td>{student.marks}</td>
                    </tr>
                ))
            }
           </tbody>
        </table>
    );

}