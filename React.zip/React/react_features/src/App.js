import logo from './logo.svg';
import './App.css';
import { Custom } from './components/Custom';
import React from 'react';
import { CustomWProps } from './components/CustomWProps';
import { ClassBasedComp } from './components/ClassBasedComp';
import { Profile } from './components/Profile';
import { ChildrenPropComp } from './components/ChildrenPropComp';
import { EventDemo } from './components/EventDemo';
import { EventDemoClass } from './components/EventDemoClass';
import { EventProp } from './components/EventProp';
import { Parent } from './components/Parent';
import { Counter } from './components/Counter';
import { Slider } from './components/Slider';
import { CounterClass } from './components/CounterClass';

// function multiply(a,b)
// {
//   return a*b;
// }

function App() {
  // let x='good evening';
  // let a=12, b=20;
  // return (<p>Hello world {a+b} </p>);
  // return (<p>{multiply(a,b)}</p>);
    
  //Using Custom Component using container placeholder React.Fragment
  // return (
  //   <React.Fragment>
  //   <h1>App Title</h1>
  //   <Custom/>
  //   </React.Fragment>
  // )

//Complex JSX
  // let x='hello';
  // let y=12;
  // let z={name:'ramesh',rollno:1,marks:19};
  // let k=<h1>Welcome {x}</h1>
  // return(
  //   <React.Fragment>
  //   <div>{k}</div>
  //   <div>
  //     <p>NAME : {z.name}</p>
  //     <p>RollNO : {z.rollno}</p>
  //     <p>Marks : {z.marks}</p>
  //   </div>
  //   <Custom></Custom>
  //   </React.Fragment>    
  // )

  //Specifying attributes in React elements
  // let url="http://www.google.com";
  // let x=<a href={url}> Go to Google </a>
  // return (
  //   x
  // )

  //Specifying attributes in React elements;
  // let url="https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/golden-retriever-royalty-free-image-506756303-1560962726.jpg?crop=0.672xw:1.00xh;0.166xw,0&resize=640:*";
  // let ele=<img src={url} width='300' height='300'/>
  // return (
  //   ele
  // )

  //Component usage with props
  // return (
  //   <CustomWProps name="Ramesh" age={20}></CustomWProps>
  // )
  

  //Class based component with props
  // return(
  //   <ClassBasedComp name='John Paul'></ClassBasedComp>
  // )

  //Example to demonstrate splitting single component
  //into multiple
  // return(
  //   <Profile name="Nobita Nobi" 
  //            imgUrl="https://i.pinimg.com/474x/e9/36/ab/e936ab240156c33be7974c2c36188bdf.jpg"
  //            age={20}
  //            mobile="9090909090"
  //            professionalHistory="used 20 years in cartoon industry"
  //            nationality="japanese"
  //            address="24 ,tokyo street , tokyo , japan"
  //            >

  //   </Profile>
  // )

  //Example to demonstrate children props.
  // return (
  //   <ChildrenPropComp title="Welcome">
  //     <p>Welcome to the react js world with full power of js
  //       along with templates knowledge.
  //     </p>
  //   </ChildrenPropComp>


  //Example of click event
  // return(
  //   <EventDemo></EventDemo>
  // );


    //Example of click event in class based component
  // return(
  //   <EventDemoClass></EventDemoClass>
  // );

  //Combination of props and event 
  // return(
  //   <React.Fragment>
  //     <EventProp name="Brock Lestner"></EventProp>
  //      <EventProp name="Stone Cold "></EventProp>
  //   </React.Fragment>
  //   );

  // return (
  //   // <Parent></Parent>
  //   <React.Fragment>
  //   <h2>Counter I</h2>
  //   <Counter></Counter>
  //   <h2>Counter 2</h2>
  //   <Counter></Counter>
  //   </React.Fragment>
  // )

  //Slider example using state
  // return(
  //   <Slider></Slider>
  // )

  //State example in class component
  return(
    <CounterClass></CounterClass>
  )

} 

export default App;
