export function EventProp(props)
{
    function handleButtonClick()
    {
        alert(props.name);
    }
    return (
        <button onClick={handleButtonClick}>Click to get My Name</button>
    )
}

















