import React from "react";
import { ProfileBody } from "./ProfileBody";
import { ProfileHeader } from "./ProfileHeader";

//Example of Composing multiple components into single.
export function Profile({name,age,professionalHistory,imgUrl,address,nationality, mobile}){
    return(

        <React.Fragment>
        {/* <div style={{padding:'10px',backgroundColor:'maroon',height:'90px'}}>
            <img src={img_url} style={{position:"relative",top:15}} width="80" height="80"/>
            <p style={{display:'inline-block',float:"right",marginRight:'20px',color:'white',fontWeight:'bold'}}>{name}</p>
        </div>

        <div style={{padding:'3%',border:'solid 1px maroon',borderRadius:'12px',width:'80%',height:'300px', marginTop:'5%',marginLeft:'10%'}}>
            <p>Age  : {age}</p>
            <p>Professional Overview   : {profession_history}</p>
            <p>Mobile  : {mobile}</p>
            <p>Nationality   : {nationality}</p>
            <p>Address : {address}</p>                        
        </div> */}
        <ProfileHeader name={name} imgUrl={imgUrl}/>
        <ProfileBody age={age} nationality={nationality} address={address}
        professionalHistory={professionalHistory}
        mobile={mobile}/>
        </React.Fragment>
    )
}