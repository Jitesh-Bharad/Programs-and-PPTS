import React from "react";

//props is not a pre-defined keyword for function components
export function CustomWProps({name,age}) 
{
    return(
        <React.Fragment>
        <h1>Welcome {name}</h1>
        <p>You age is {age+1}</p>
        </React.Fragment>
        )
}

// export function CustomWProps(props) 
// {
//     return(
//         <React.Fragment>
//         <h1>Welcome {props.name}</h1>
//         <p>You age is {props.age}</p>
//         </React.Fragment>
//         )
// }