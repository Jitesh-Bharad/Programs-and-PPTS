import React, { useState } from "react";
export function Counter()
{
  const[count,setCount] =useState(0);
  
  function increment()
  {
    setCount(count+1);
  }
  function decrement()
  {
    setCount(count-1);
  }
  return(
    <React.Fragment>
    <p>Current Count : {count} </p>
    <button onClick={increment}>+</button>    
    <button onClick={decrement}>-</button>    
    </React.Fragment>
  )
}