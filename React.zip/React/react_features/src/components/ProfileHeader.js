export function ProfileHeader({name,imgUrl})
{
    return (
        <div style={{padding:'10px',backgroundColor:'maroon',height:'90px'}}>
            <img src={imgUrl} style={{position:"relative",top:15}} width="80" height="80"/>
            <p style={{display:'inline-block',float:"right",marginRight:'20px',color:'white',fontWeight:'bold'}}>{name}</p>
        </div>
    )
}