import React, { useState } from "react";
import { dogs } from "./Dogs";

export function Slider()
{
    const [currentIndex,setCurrentIndex]=useState(0);

    function handleNextClick()
    {
        setCurrentIndex(currentIndex+1);
    }

    return(
        <React.Fragment>
        <p>{process.env.PUBLIC_URL}</p>
        <div>
            <figure>
                <img src={dogs[currentIndex].imgUrl} width='300' height='200'/>
                <figcaption>{dogs[currentIndex].category}</figcaption>
            </figure>
            <button onClick={handleNextClick}>Next</button>
        </div>
        </React.Fragment>
    )
}

index =1;
x=[{name:'abc',age:12},{name:'def',age:90},{name:'mno',age:10}]

x[1].name 
x[1].age
