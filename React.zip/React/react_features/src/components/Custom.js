import React from "react";

export function Custom(){
    return (
        <React.Fragment>
        <h1>Title</h1>
        <p>First Custom Component Here....Hello</p>
        </React.Fragment>
    );
}