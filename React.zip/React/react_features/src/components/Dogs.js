export const dogs=[
    {category:'Labra',imgUrl:'images/labra.jpg'},
    {category:'German Shepherd',imgUrl:'images/German_Shepherd.jpg'},
    {category:'Golden Retriever',imgUrl:'images/golden_retriever.jpg'},
    {category:'Pug',imgUrl:'images/pug.jpg'},
    {category:'Doberman',imgUrl:'images/Doberman.jpg'},
]
