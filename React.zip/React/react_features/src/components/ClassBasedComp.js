import React from "react";
// export function ClassBasedComp(props){
//     return (
//         <p> Welcome {props.name}</p>
//     )
// }

//Step 1 : Create a class that extends React.Component.
//Step 2 : create the constructor with props as arguments.
//Step 3 : In the first line of constructor, call super(props)
//Step 4 : Override render method to return the react elements from it.

export class ClassBasedComp extends React.Component{
    constructor(props)
    {
        super(props);
    }
    render()
    {
       return(
        <p>Welcome {this.props.name}</p>
       ) 
    }
}