import React from "react";

export const ChildrenPropComp=(props)=>{

    return (
        <React.Fragment>
        <h1>{props.title}</h1>
        <div>{props.children}</div>           
        </React.Fragment>
    )
}