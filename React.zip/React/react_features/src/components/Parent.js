import React  from "react";
import { Child } from "./Child";

export function Parent(){
    let pName="Parent";
    function getDataFromChild(childName)
    {
        alert("My child name is : "+childName);
    }
    return(        
        <React.Fragment>
        <p>Parent starts</p>
        <Child sendToParent={getDataFromChild} parentName={pName}/>
        <p>Parent ends </p>
        </React.Fragment>
    )
}