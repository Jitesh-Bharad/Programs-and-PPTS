import React from "react";

export function Child(props){

    let childName='Child';

    return(
        <React.Fragment>
        <p>Child here </p>
        <p>My father's name is {props.parentName}</p>
        <button onClick={()=>{props.sendToParent(childName)}}>Sent To parent</button>
        </React.Fragment>
    )
}