export function ProfileBody(props)
{
    return(
        <div style={{padding:'3%',border:'solid 1px maroon',borderRadius:'12px',width:'80%',height:'300px', marginTop:'5%',marginLeft:'10%'}}>
        <p>Age  : {props.age}</p>
        <p>Professional Overview   : {props.professionalHistory}</p>
        <p>Mobile  : {props.mobile}</p>
        <p>Nationality   : {props.nationality}</p>
        <p>Address : {props.address}</p>                        
    </div> 
    )
}