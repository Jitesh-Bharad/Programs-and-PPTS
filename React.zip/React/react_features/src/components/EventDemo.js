import React from "react";

export function EventDemo(){
  
    function handleClick(e)
    {
        console.log(e.target.innerHTML);
    }

    function handleNameChange(e){
        console.log(e.target.value);
    }

    function handleMouseOverDiv(e){
        console.log(e.target);
    }
    return(
        <React.Fragment>
            <div onMouseOver={handleMouseOverDiv} style={{background:'red',width:'100px',height:'100px'}}>
                <p>Hello World</p>
                <h2>Good Noon</h2>
            </div>
          <input type="text" placeholder="Enter name" onChange={handleNameChange} />
         <button style={{background:'gray',color:'red'}} name='button1' onClick={handleClick}>B1</button>
         <button style={{background:'black',color:'white'}} name='button2' onClick={handleClick}>B2</button>
        </React.Fragment>
        )
}


















