import React from "react";

export class CounterClass extends React.Component{

  constructor(props)
  {
    super(props);
    this.state={count:0};
  }
  increment()
  {
    //Updating state which is dependent on previous state
    this.setState((prevState)=>{return {count:prevState.count+1}})    
  }
  decrement()
  {
    this.setState((prevState)=>{return {count:prevState.count-1}})
  }
  render()
  {
    return (
      <React.Fragment>
      <p>{this.state.count}</p>
      <button onClick={this.increment.bind(this)}>+</button>
      <button onClick={this.decrement.bind(this)}>-</button>
      </React.Fragment>
    )
  }
}

