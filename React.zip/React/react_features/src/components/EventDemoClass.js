import React from "react";

export class EventDemoClass extends React.Component{

    constructor(props)
    {
        super(props)
    }

    handleClick(e){
        alert('clicked');
    }

    handleNameChange=(e)=>{
        console.log(e.target.value);
    }

    render()
    {
        return(
            <React.Fragment>
           <input type="text" placeholder="Enter name" onChange={this.handleNameChange}/>
            <button onClick={this.handleClick}>Click Me</button>
            </React.Fragment>
        );
    }
}