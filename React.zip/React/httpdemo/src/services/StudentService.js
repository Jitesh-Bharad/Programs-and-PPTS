import axios from "axios";
import { Config } from "../Config";

function preProcessStudents(obj)
{
 let items=[];
 for(let id in obj)
 {
    let i={...obj[id],id:id};
    items.push(i);
 }   
 return Promise.resolve(items);
}

export async function getAllStudents()
{
    // let dataStream=await fetch(Config.STUDENT_URL);
    // let rawStudentsData=await dataStream.json();
    // return preProcessStudents(rawStudentsData);
    try{
        let rawObj= await axios.get(Config.STUDENT_URL);
        console.log('service : ')
        return preProcessStudents(rawObj.data);    
    }
    catch(e){
        console.log(e);
        throw e.response.data;
    }
}

export async function addStudent(student)
{
    // let dataStream=await fetch(Config.STUDENT_URL,{
    //     method:'POST',
    //      body:JSON.stringify(student)    
    // });
    // let resp=await dataStream.json();
    // return resp;

    let r=await axios.post(Config.STUDENT_URL,student);
    console.log(r);
    return r;
}