import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getAllStudents } from "../services/StudentService";

export function ListFunctional(){

    const[students,setStudents]=useState([]);
    const[loading,setLoading]=useState(false)
    const params=useParams();

    useEffect(()=>{
        console.log(params.id);
        async function fetchAll()
        {
            await setLoading(true);
            let students=await getAllStudents();
            await setStudents(students);
            await setLoading(false);                 
        }
        fetchAll();
    },[])

   let ui=loading?<p>....Loading...</p>:
                <table>
                    <thead>
                        <tr>
                            <td>Name</td>
                            <td>RollNo</td>
                            <td>Marks</td>                        
                        </tr>
                    </thead>
                    <tbody>
                        {
                            students.map((student)=>{return (
                                <tr key={student.id}>
                                    <td>{student.name}</td>
                                    <td>{student.rollno}</td>
                                    <td>{student.marks}</td>
                                </tr>)
        })
                        }                   
                    </tbody>
                </table>
    console.log(students);
    return ui;
    // render()
    // {

    //     if(loading){
    //         return (
    //             <p>.....Loading.....</p>
    //         )
    //     }
    //     else{
    //         return(
    //             <table>
    //                 <thead>
    //                     <tr>
    //                         <td>Name</td>
    //                         <td>RollNo</td>
    //                         <td>Marks</td>                        
    //                     </tr>
    //                 </thead>
    //                 <tbody>
    //                     {
    //                         students.map((student)=>{return (
    //                             <tr key={student.id}>
    //                                 <td>{student.name}</td>
    //                                 <td>{student.rollno}</td>
    //                                 <td>{student.marks}</td>
    //                             </tr>)
    //     })
    //                     }                   
    //                 </tbody>
    //             </table>
    //         )    
    //     }
    // }
}