import React from "react";

export function Home()
{
 return (
    <React.Fragment>
    <p>Home Here</p>
    <button className="btn btn-primary">Test</button>
    </React.Fragment>
 )   
}