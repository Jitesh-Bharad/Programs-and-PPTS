import React from "react";
import { addStudent } from "../services/StudentService";

export class Add extends React.Component{

    constructor(props)
    {
        super(props);
        this.state={loading:false,student:{name:'',rollno:0,marks:0}};

       this.handleChangeMarks=this.handleChangeMarks.bind(this);
       this.handleChangeName= this.handleChangeName.bind(this);
       this.handleChangeRollno= this.handleChangeRollno.bind(this);   
       this.handleSubmit= this.handleSubmit.bind(this)
    }

   async componentDidMount()
    {
    }

   async handleSubmit(e)
    {
        e.preventDefault();
        let resp=await addStudent(this.state.student);
        console.log(resp);
    }
    
    handleChangeName(e)
    {
        this.setState({student:{...this.state.student,name:e.target.value}});
    }
    handleChangeRollno(e)
    {
        this.setState({student:{...this.state.student,rollno:e.target.value}});
    }
    handleChangeMarks(e)
    {
        this.setState({student:{...this.state.student,marks:e.target.value}});
    }
    render()
    {
        return (
            <form onSubmit={this.handleSubmit}>
                <input onChange={this.handleChangeName} type='text' placeholder="Enter name"/>
                <input onChange={this.handleChangeRollno} type='number' placeholder="Enter rollno"/>
                <input onChange={this.handleChangeMarks} type='number' placeholder="Enter marks"/>
                <input type='submit' value='Add'/>
            </form>
        )
    }
    
}