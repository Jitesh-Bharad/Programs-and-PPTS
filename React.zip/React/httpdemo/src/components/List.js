import React from "react";
import { getAllStudents } from "../services/StudentService";

export class List extends React.Component{
    constructor(props)
    {
        super(props);
        this.state={loading:false,students:[],error:null};
    } 
   async componentDidMount()
    {
        try{
            await this.setState({loading:true}); 
            let students=await getAllStudents();
            await this.setState({students:students,loading:false});     
        }catch(error)
        {
            this.setState({error:error.error,loading:false});        
        }
        
        // fetch(url).then((response)=>(
        //      response.json()
        // )).then((students)=>{
        //     return this.preProcessStudents(students);
        // }).then((students)=>{
        //     this.setState({students:students,loading:false});
        // })
    }
    
    render()
    {

        if(this.state.loading){
            return (
                <p>.....Loading.....</p>
            )
        }
        else{
            if(this.state.error)
            {
                return <p>{this.state.error}</p>
            }
            return(
                <table>
                    <thead>
                        <tr>
                            <td>Name</td>
                            <td>RollNo</td>
                            <td>Marks</td>                        
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.students.map((student)=>{return (
                                <tr key={student.id}>
                                    <td>{student.name}</td>
                                    <td>{student.rollno}</td>
                                    <td>{student.marks}</td>
                                </tr>)
        })
                        }                   
                    </tbody>
                </table>
            )    
        }
    }
}






