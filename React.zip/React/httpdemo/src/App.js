import './App.css';
import { List } from './components/List';
import { Add } from './components/Add';
import { Navbar } from './components/Navbar';
import React from 'react';
import { BrowserRouter, Route, Router, Routes } from 'react-router-dom';
import { Home } from './components/Home';
import 'bootstrap/dist/css/bootstrap.min.css';
import { ListFunctional } from './components/ListFunctional';

function App() {
  return (
    <BrowserRouter>
    <Navbar></Navbar>
     <Routes>
      <Route path='home' element={<Home/>}></Route>
      <Route path='add' element={<Add/>}></Route>
      <Route path='list' element={<List/>}></Route>      
     <Route  path='listfunctional/:id' element={<ListFunctional></ListFunctional>}></Route>
     </Routes>
    </BrowserRouter>    
    // <Add></Add>
  )
}

export default App;
