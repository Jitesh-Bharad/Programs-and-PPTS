export class Config{
    static STUDENT_URL='https://testapis-c90ab-default-rtdb.firebaseio.com/students.json'

}