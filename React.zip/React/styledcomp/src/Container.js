import styled from "styled-components";

export const Container= styled.div`
margin-left:20%;
width:700px;
border:solid 1px pink;
border-radius:8px;
min-height:200px;
text-align:center;

@media (min-width:0px) and (max-width:600px){
    width:300px;
}

&:hover{
    box-shadow:2px 2px 5px 3px lightgray;
}
`

