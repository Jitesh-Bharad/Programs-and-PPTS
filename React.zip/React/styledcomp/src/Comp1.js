import './Comp1.css'
export function Comp1()
{
    return (
        <p className="test">Hello World</p>
    )
}