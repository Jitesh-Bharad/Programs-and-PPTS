import './Comp2.css'

export function Comp2()
{
    return (
        <p className="test">Hello World</p>
    )
}