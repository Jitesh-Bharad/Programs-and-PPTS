import logo from './logo.svg';
import './App.css';
import { Button } from './Button';
import { Comp1 } from './Comp1';
import React from 'react';
import { Comp2 } from './Comp2';
import { Container } from './Container';

function App() {
  return (
    // <React.Fragment>
    // <Comp1></Comp1>
    // <Comp2></Comp2>   
    // </React.Fragment>
    // <Container>
    //   <input type='text' placeholder='Enter name'/>
    // </Container>
    <React.Fragment>
    <Button>Normal</Button>
    <Button primary>Primary</Button>
    </React.Fragment>    
    );
}

export default App;
