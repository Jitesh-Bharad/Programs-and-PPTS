import styled from "styled-components";

export const Button=styled.button`
background:${props => props.primary?'black':'white'};
color:${props => props.primary?'white':'navyblue'};
font-size:25px;
padding:5px;
border:solid 1px red;
&:hover{
    box-shadow:2px 2px 5px gray;
}
`