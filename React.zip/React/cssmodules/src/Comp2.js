import Comp2Style from './Comp2.module.css';

export function Comp2(props)
{
    let allClasses=`${Comp2Style.test}`;

    if(props.bold)
    {
        let boldClass=` ${Comp2Style.test2}`
       allClasses=allClasses+boldClass;
    }

    return (
        <p className={allClasses}>Good Morning </p>
    )
}
// constructor()

// componentDidMount(only once) : operation that need to be done once , like http requests to fetch initial Data . 

// componentDidUpdate

// componentWillUnmount : resource deallocations or unsubscribing from 
// subscriptions can be done here






// useEffect is the hook in function based component , which will act as 
// componentDidMount , componentDidUpdate and componentWillUnmount.

// It means each time a component is initialzed successfully , useEffect will be called. Same will be called when component state will be updated and same will be called when component is about to be destroyed .