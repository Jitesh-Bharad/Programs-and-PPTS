import logo from './logo.svg';
import './App.css';
import { Comp1 } from './Comp1';
import React from 'react';
import { Comp2 } from './Comp2';

function App() {
  return (
    <React.Fragment>
    <Comp1></Comp1>
    <Comp2 bold></Comp2>
    </React.Fragment>
  );
}

export default App;
