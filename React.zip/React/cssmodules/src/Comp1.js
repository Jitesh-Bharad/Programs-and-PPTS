import Comp1Style from  './Comp1.module.css';

export function Comp1()
{
    return (
        <p className={Comp1Style.test}>Hello World</p>
    )
}