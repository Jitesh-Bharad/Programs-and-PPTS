async function add(a,b)
{
 return new Promise((resolve)=>{
        resolve(a+b)
    })
}

let x=await add(1,32);