(function()
{
    console.log('hello');
    console.log('world');
    console.log('good');
})();