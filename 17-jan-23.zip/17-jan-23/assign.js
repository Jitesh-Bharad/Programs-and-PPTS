let obj={name:'ramesh',rollno:1};
let obj1={dept:'cs',name:'suresh'};
let obj2=Object.assign(obj1,obj);
console.log(obj);
console.log(obj1);
console.log(obj2);
obj1.name='johhn';
console.log(obj);
console.log(obj1);

//hello world get up