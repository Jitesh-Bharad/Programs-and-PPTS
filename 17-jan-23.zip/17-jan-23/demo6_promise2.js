async function gather()
{
    return new Promise((resolve)=>{
        setTimeout(()=>{
            console.log('gather');
            resolve()
        },1200)        
    })
}

async function enter()
{
    return new Promise((resolve)=>{
        setTimeout(()=>{
            console.log('enter');
            resolve();
        },200)        
    })
}

async function order()
{
    return new Promise((resolve)=>{
        setTimeout(()=>{
            console.log('order')
            resolve()
        },800)        
    })
}

async function eat()
{    
    return new Promise((resolve)=>{
    setTimeout(()=>{
        console.log("eating");
        resolve();
    },500)        
})
}

async function payBill()
{
    return new Promise((resolve)=>{
        setTimeout(()=>{
            console.log('pay bill')
            resolve();
        },1000)        
    })
}

async function exit()
{
    return new Promise((resolve)=>{
        setTimeout(()=>{
            console.log('exit')
            resolve()
        },200)        
    })
}

async function test(){
   await gather();
   await enter();
   await order();
   await eat();
   await payBill();
   await exit();
}


(async ()=>{
console.log('hello');
await test();
console.log('world');
})();