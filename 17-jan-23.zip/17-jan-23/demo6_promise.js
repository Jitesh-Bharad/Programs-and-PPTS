function gather()
{
    return new Promise((resolve)=>{
        setTimeout(()=>{
            console.log('gather');
            resolve()
        },1200)        
    })
}
function enter()
{
    return new Promise((resolve)=>{
        setTimeout(()=>{
            console.log('enter');
            resolve();
        },200)        
    })
}
function order()
{
    return new Promise((resolve)=>{
        setTimeout(()=>{
            console.log('order')
            resolve()
        },800)        
    })
}
function eat()
{    
    return new Promise((resolve)=>{
    setTimeout(()=>{
        console.log("eating");
        resolve();
    },500)        
})
}

function payBill()
{
    return new Promise((resolve)=>{
        setTimeout(()=>{
            console.log('pay bill')
            resolve();
        },1000)        
    })
}
function exit()
{
    return new Promise((resolve)=>{
        setTimeout(()=>{
            console.log('exit')
            resolve()
        },200)        
    })
}

function test(){
    gather()
    .then(()=>enter())
    .then(()=>order())
    .then(()=>eat())
    .then(()=>payBill())
    .then(()=>exit());    
}

test();

