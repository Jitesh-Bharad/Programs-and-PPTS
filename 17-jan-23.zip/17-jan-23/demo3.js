setTimeout(()=>{
    console.log('gather');
    setTimeout(()=>{
        console.log('enter');
        setTimeout(()=>{
            console.log('order');
            setTimeout(()=>{
                console.log('eating');
                setTimeout(()=>{
                    console.log('paybill');
                    setTimeout(()=>{
                        console.log('exit')
                    },200);
                },800);
            },300);
        },
        500);
    },200);
},1000);



//Pyramid of doom
//callback hell