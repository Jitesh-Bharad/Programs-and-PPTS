function test(age)
{
  let pr= new Promise((resolve,reject)=>{
    setTimeout(()=>{
        if(age>=18)
        {
            resolve('voted successfully');
        }
        else{
            reject("age not sufficient")
        }
    },500)
    });
    return pr;
}

console.log('hello');
let resultPromise=test(6);
resultPromise
.then((result)=>{console.log(result)})
.catch((error)=>{console.log(error)})
.finally(()=>{console.log('finally')});
console.log('world');











