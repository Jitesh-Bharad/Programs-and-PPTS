// let x={fname:'mickky',empid:1,salary:900000};
// let y=Object.assign({},x);
// y.fname='mouse';
// console.log(x);//{fname:'mickky',empid:1,salary:900000}
// console.log(y);//{fname:mouse,empid:1,salary:900000}
let x={fname:'mickky',empid:1,salary:900000,address:{hno:1,city:'new delhi',state:'delhi'}};
let y={...x};
console.log(x);
console.log(y);
y.address.hno=2;
console.log(x.address);//{hno:2,city:new delhi,state:'delhi'}
console.log(y.address);//{hno:2,city:new delhi,state:"delhi"}
