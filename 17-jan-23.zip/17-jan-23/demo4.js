function gather(callback)
{
    setTimeout(()=>{
        console.log('gather');
        callback(order);
},200);
}

function enter(callback)
{
    setTimeout(()=>{
        console.log('enter');
        callback(eat);
},1000);    
}

function order(callback)
{
 setTimeout(() => {
    console.log('order');
    callback(payBill);
 }, 500);
}

function eat(callback)
{
    setTimeout(() => {
        console.log('eating');
        callback(exit);
    }, 500);
}

function payBill(callback)
{
    setTimeout(()=>{
        console.log('pay bill');
        callback();
    },800)
}

function exit()
{
    setTimeout(() => {
        console.log('exit');
    }, 200);    
}

gather(enter);
