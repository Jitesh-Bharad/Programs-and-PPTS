setTimeout(()=>{console.log('gather')},1000);
setTimeout(()=>{console.log('enter')},200);
setTimeout(()=>{console.log('order')},500);
setTimeout(()=>{console.log('eating')},300);
setTimeout(()=>{console.log('paybill')},800);
setTimeout(()=>{console.log('exit')},200);


