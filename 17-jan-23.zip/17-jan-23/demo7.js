function square(num)
{
    return new Promise((resolve)=>{
        let result=1;
        setTimeout(()=>{
            result=num*num;
            resolve(result);
        },200)
})
}

function factorial(num)
{
    return new Promise((resolve)=>{
        setTimeout(()=>{
            let fact=1;
            for(let i=num;i>=1;i--)
            {
                fact=fact*i;
            }
            resolve(fact);
        },1200)        
    })
}
factorial(3)
.then((result)=>{ return square(result)})
.then((result)=>{console.log(result)})


//1. Create a function to find the maximum element of an array
//the function will take array as argument and return a promise.


//2. Create 2 functions add and multiply10 , add will
//take 2 arguments and return their addition, the 
//result of addition will be passed as argument to 
//multiply10 and multiply10 will return the value
//by multiplying 10 to the input argument.
//Make use of async await. use setTimeout in functions. 

