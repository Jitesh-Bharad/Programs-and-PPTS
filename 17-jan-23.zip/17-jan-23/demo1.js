console.log('hello');
setTimeout(function(){console.log('good')},1000);
console.log('world');
