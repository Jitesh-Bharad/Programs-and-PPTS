import { Component, OnInit } from '@angular/core';
import {UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { Subscription } from 'rxjs';
import { TimerService } from '../timer.service';

@Component({
  selector: 'app-a',
  templateUrl: './a.component.html',
  styleUrls: ['./a.component.css']
})
@UntilDestroy()
export class AComponent implements OnInit {

  constructor(private tServ:TimerService) { }

  current:number=0;
  intervalObj:any;
  subscriptionObj!:Subscription;

  ngOnInit(): void {
    this.intervalObj=this.tServ.getInterval();
  }

  start()
  {
    // this.subscriptionObj=this.intervalObj.subscribe((val:any)=>{
    //   this.current=val;
    //   console.log(val);
    // })

        this.subscriptionObj=this.intervalObj.
        pipe(untilDestroyed(this))
        .subscribe((val:any)=>{
      this.current=val;
      console.log(val);
    })
  }

  ngOnDestroy()
  {
    // this.subscriptionObj.unsubscribe();
  }
}
