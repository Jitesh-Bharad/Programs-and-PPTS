import { ThisReceiver } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { interval, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TimerService {

  intervalObs=interval(1000);

  constructor() { }

  getInterval():Observable<any>{
    return this.intervalObs;
  }
}
