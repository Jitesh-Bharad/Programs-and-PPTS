import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanDeactivate, RouteConfigLoadEnd, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { CComponent } from './c/c.component';
import { LeaveGuardInterface } from './leave.guard.interface';

@Injectable({
  providedIn: 'root'
})
export class LeaveGuard implements CanDeactivate<unknown> {
  canDeactivate(
    component: LeaveGuardInterface,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

      return component.canExit();
  }
  
}
