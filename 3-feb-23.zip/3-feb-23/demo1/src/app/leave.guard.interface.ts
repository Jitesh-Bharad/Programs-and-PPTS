export interface LeaveGuardInterface{ 
    canExit():boolean;
}