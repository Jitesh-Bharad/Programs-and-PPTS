import { Component, OnInit } from '@angular/core';
import { LeaveGuardInterface } from '../leave.guard.interface';

@Component({
  selector: 'app-c',
  templateUrl: './c.component.html',
  styleUrls: ['./c.component.css']
})
export class CComponent implements OnInit,LeaveGuardInterface {

  constructor() { }

  ngOnInit(): void {
  }

  canExit()
  {
   return confirm('Are you sure you want to exit Component C? ')
  }

}
