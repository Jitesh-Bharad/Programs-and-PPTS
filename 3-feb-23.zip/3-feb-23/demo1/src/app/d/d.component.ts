import { Component, OnInit } from '@angular/core';
import { LeaveGuardInterface } from '../leave.guard.interface';

@Component({
  selector: 'app-d',
  templateUrl: './d.component.html',
  styleUrls: ['./d.component.css']
})
export class DComponent implements OnInit,LeaveGuardInterface {

  constructor() { }

  canExit(): boolean {
    return confirm('Are you sure to leave D Component');
  }

  ngOnInit(): void {
  }

}
