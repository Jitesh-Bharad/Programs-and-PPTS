import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AComponent } from './a/a.component';
import { A1Component } from './a1/a1.component';
import { A2Component } from './a2/a2.component';
import { BGuard } from './b.guard';
import { BComponent } from './b/b.component';
import { CComponent } from './c/c.component';
import { DComponent } from './d/d.component';
import { LeaveGuard } from './leave.guard';
import { NotfoundComponent } from './notfound/notfound.component';

const routes: Routes = [
  {path:'',component:AComponent,  
  children:[{path:'a1',component:A1Component},
            {path:'a2',component:A2Component},
          ]},
  {path:'a',component:AComponent,  
  children:[{path:'a1',component:A1Component},
            {path:'a2',component:A2Component},
          ]},
  {path:'b',canActivate:[BGuard],component:BComponent},  
  {path:'c',canDeactivate:[LeaveGuard],component:CComponent},  
  {path:'d',canDeactivate:[LeaveGuard],component:DComponent},      
  {path:'**',component:NotfoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
