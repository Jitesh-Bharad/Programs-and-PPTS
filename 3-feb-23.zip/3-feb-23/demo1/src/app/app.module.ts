import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AComponent } from './a/a.component';
import { BComponent } from './b/b.component';
import { A1Component } from './a1/a1.component';
import { A2Component } from './a2/a2.component';
import { NotfoundComponent } from './notfound/notfound.component';
import { CComponent } from './c/c.component';
import { DComponent } from './d/d.component';

@NgModule({
  declarations: [
    AppComponent,
    AComponent,
    BComponent,
    A1Component,
    A2Component,
    NotfoundComponent,
    CComponent,
    DComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
