import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  constructor(private stdServ:StudentService,
             private router:Router) { }
  students:any=[];

  ngOnInit(): void {
    this.stdServ.getAll().subscribe((std)=>{
      this.students.push(std);
    })
  }


  openDetails(rollno:number)
  {
    this.router.navigate(['detail',rollno]);// /detail/1
//    console.log(`hello : ${rollno}`);

  }

}
