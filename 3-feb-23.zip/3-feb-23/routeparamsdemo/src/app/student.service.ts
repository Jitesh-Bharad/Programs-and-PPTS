import { Injectable } from '@angular/core';
import { filter, from } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor() { }

  students=[
    {name:'ramesh',rollno:1,marks:99,dept:'cs',city:'pune'},
    {name:'suresh',rollno:2,marks:100,dept:'it',city:'bangalore'},
    {name:'john',rollno:3,marks:80,dept:'ec',city:'hyderabad'},
    {name:'paul',rollno:4,marks:89,dept:'it',city:'new delhi'},
    {name:'naveen',rollno:5,marks:70,dept:'mech',city:'indore'},
    {name:'jishnu',rollno:6,marks:80,dept:'it',city:'chennai'},
  ]

  getAll(){
   return from(this.students);
  }


  getStudentDetails(rollno:number){
    return from(this.students).pipe(filter((std)=>{
      return std.rollno==rollno;
    }))    
  }
  
}
