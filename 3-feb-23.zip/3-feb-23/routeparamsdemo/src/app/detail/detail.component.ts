import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {

  constructor(private currentRoute:ActivatedRoute,
              private stdService:StudentService) { }

  rollno!:number;
  detail:any;

  ngOnInit(): void {
    this.currentRoute.params.subscribe((obj:any)=>{
      this.rollno=obj['rollno'];
      this.stdService.getStudentDetails(this.rollno).subscribe((detail)=>{
        this.detail=detail;
      });
    })

  }

}
