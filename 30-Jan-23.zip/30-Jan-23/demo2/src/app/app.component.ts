import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo2';
  age=19;
  name='';
  month=1;
  names=['abc','def','xyz','john','paul'];
  std=[{name:'john',rollno:1,marks:90},
        {name:'paul',rollno:2,marks:89},
        {name:'muskan',rollno:3,marks:99}
      ];
  addName()
  {
    this.names.push(this.name);
  }

  delete(roll:number)
  {
    console.log(roll);
  }
}
