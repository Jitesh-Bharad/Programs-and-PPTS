import { SqrPipe } from './sqr.pipe';

describe('SqrPipe', () => {
  it('create an instance', () => {
    const pipe = new SqrPipe();
    expect(pipe).toBeTruthy();
  });
});
