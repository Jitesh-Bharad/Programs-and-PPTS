import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demopipe';
  name='kamlesH ShaRma';
  amount=1200;
  avgMarksPerc=3/4;
  roi=1/8;  
  std={name:'anshika verma',rollno:90,marks:89};
  price=8999.2;
  dt=new Date();
}
