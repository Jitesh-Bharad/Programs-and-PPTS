type Style={
    'background-color'?:string;
    'width':string;
    'height':string;
}