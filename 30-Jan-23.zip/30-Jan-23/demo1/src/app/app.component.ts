import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo1';
  age=19;
  classes=['test','test1'];
  classObj={'test':false};
  bgColor='red';

  applyBG()
  {
    this.styleObj['background-color']=(this.age>18)?'red':'blue';
  }
  styleObj:Style={'width':'100px','height':'100px'}
 // styleObj={backgroundColor:'blue',width:'100px',height:'100px'}

}
