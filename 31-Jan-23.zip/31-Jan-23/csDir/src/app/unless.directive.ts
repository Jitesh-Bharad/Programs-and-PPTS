import { Directive, Input, OnChanges, SimpleChanges, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[unless]'
})
export class UnlessDirective implements OnChanges{

  @Input() unless!:boolean;

  constructor(private container:ViewContainerRef,private template:TemplateRef<any>) {

   }   
  ngOnChanges(changes: SimpleChanges): void {
    if(this.unless)
    {
    this.container.clear();  
    }else{
      this.container.createEmbeddedView(this.template);
    }
  }

}
