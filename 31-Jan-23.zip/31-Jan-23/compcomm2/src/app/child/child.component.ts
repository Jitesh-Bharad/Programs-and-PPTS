import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent{

  constructor() { }
  name:string='';

  @Output() getName:EventEmitter<string>=new EventEmitter();
 
  sendToParent()
  {
    this.getName.emit(this.name);
  }
}
