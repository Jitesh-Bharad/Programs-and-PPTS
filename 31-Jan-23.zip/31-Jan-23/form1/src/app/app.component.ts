import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'form1';

  submit(value:any)
  {
   console.log('submit called'); 
   console.log(value);
  }
}
