import { Directive,HostListener, ElementRef, Input, OnChanges, SimpleChanges } from '@angular/core';
@Directive({
  selector: '[color]'
})
export class ColorDirective {
  @Input() enterColor!:string;
  @Input() exitColor!:string;
  constructor(private ref:ElementRef) { 
   }

   ngOnInit()
   {
   }
  @HostListener('mouseover')
  onMouseOver()
  {
    this.ref.nativeElement.style.background=this.enterColor;    
  }

  @HostListener('mouseout')
  onMouseOut()
  {
    this.ref.nativeElement.style.background=this.exitColor;    
  }
}










// If we want to receive the events of host element inside Directive
// then @HostListener is the decorator which can be used to listen 
// such events inside Directive.





