import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'demo1';
  username:string='John';
  password:string='Paul';

  showDetails()
  {
    console.log('hello world');
  }
}
