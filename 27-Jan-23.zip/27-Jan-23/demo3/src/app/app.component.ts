import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, DoCheck, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit,OnChanges,DoCheck,AfterContentInit,AfterContentChecked,AfterViewInit,AfterViewChecked,OnDestroy {

  username!:string;

  ngOnInit(): void {
    console.log('init');
  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log('ng on changes');
  }
  ngDoCheck(): void {
    console.log('ng do check');
  }
  ngAfterContentInit(): void {
    console.log('after content init');
  }
  ngAfterContentChecked(): void {
    console.log('afte content checked');
  }
  ngAfterViewInit(): void {
    console.log('after view init');
  }
  ngAfterViewChecked(): void {
    console.log('after view checked');
  }
  ngOnDestroy(): void {
    console.log('destroy');
  }

  title = 'demo3';

}
