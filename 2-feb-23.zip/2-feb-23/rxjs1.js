import { Observable ,from} from 'rxjs';

let x=[12,90,100,89,78,65];

let observable=from(x);

//Producer
const observable = new Observable((subscriber) => {
  console.log('hello obserable');
  subscriber.next(1);//emit data 1
  subscriber.next(2);//emit data 2
  subscriber.next(3);//emit data 3
  setTimeout(() => {
    subscriber.next(4);//emit data 4
    subscriber.complete();
  }, 1000);
});



// //Consumer
let observer={
  next:(data)=>{console.log(data)},
  error:(err)=>{console.log(err)},
  complete:()=>{console.log('observable complete')}
}
observable.subscribe(observer);