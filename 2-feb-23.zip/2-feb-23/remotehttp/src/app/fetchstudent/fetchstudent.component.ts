import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { Student } from '../types/Student';
@Component({
  selector: 'app-fetchstudent',
  templateUrl: './fetchstudent.component.html',
  styleUrls: ['./fetchstudent.component.css']
})
export class FetchstudentComponent {

  constructor(private serv:StudentService) { }
  students:Student[]=[];
  
  ngDoCheck(): void {
    this.serv.fetchAll()
             .subscribe((students)=>{
              this.students=students;
             })  
  }

  delete(id:any)
  {
    this.serv.delete(id).subscribe((result)=>{console.log(result)});
  }
}
