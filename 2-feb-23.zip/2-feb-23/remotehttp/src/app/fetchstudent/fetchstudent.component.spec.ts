import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FetchstudentComponent } from './fetchstudent.component';

describe('FetchstudentComponent', () => {
  let component: FetchstudentComponent;
  let fixture: ComponentFixture<FetchstudentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FetchstudentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FetchstudentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
