export type Student={
    name:string,
    rollno:number,
    marks:number,
    id?:string
}