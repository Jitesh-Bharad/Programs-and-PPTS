import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Student } from './types/Student';
import {map,Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class StudentService {

  constructor(private httpServ:HttpClient) {

   }

   preprocessToArray(obj:any):Student[]
   {
    let result:Student[]=[];
    for(let id in obj)
    {
      let std:Student={...obj[id],id:id};
      result.push(std);
    }
    return result;
   }


   add(std:Student)
   {
    let url="https://testapis-c90ab-default-rtdb.firebaseio.com/students.json";

    this.httpServ.post(url,std,{observe:'response'})
    .subscribe((response)=>{
      console.log(response);
    })
   }

   delete(id:string)
   {
    let url=`https://testapis-c90ab-default-rtdb.firebaseio.com/students/${id}.json`;
   return  this.httpServ.delete(url);
   }

   fetchAll():Observable<Student[]>
   {
    let url="https://testapis-c90ab-default-rtdb.firebaseio.com/students.json";

    return this.httpServ.get(url,{observe:'response'})
                .pipe(
                  map((response:any)=>{ 
                    return this.preprocessToArray(response.body)
                  })
                  )
   }

}
