import { Component } from '@angular/core';
import { CountryService } from './country.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'httpDemo';
  showMsg:boolean=false;
  erroMsg='There was some problem fetching data....';
  countries!:any[];
  constructor(private country:CountryService){

  }
  ngOnInit()
  {
    this.country.getAll().subscribe((response:any)=>{
      if(response.status==200){
        this.countries=response.body;
      }
      else{
        this.showMsg=true;
      }
    });
  }
}
