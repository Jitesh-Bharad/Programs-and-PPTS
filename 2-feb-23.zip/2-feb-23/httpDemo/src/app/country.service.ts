import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CountryService {

  constructor(private http:HttpClient) { }

  getAll()
  {
    let url="https://restcountries.com/v3.1/all";
    return this.http.get(url,{observe:'response'});
  }
}
