import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'good';
  num1=12;
  num2=90;
  fname='doraemon';
  disable:boolean=false;
  getMessage()
  {
    return "hello good evening";
  }
  submit()
  {
    console.log('button clicked ');    
    this.num1++;
  }
  toggle(){
    this.disable=!this.disable;
  }

  setGender(ev:any)
  {
   console.log(ev.target.value); 
  }


}
